const test = require('node:test');
const assert = require('node:assert/strict');
const { io: createClient } = require('socket.io-client');
const { server, io, rooms, cleanName, circleHitsWall } = require('../server');

let baseUrl;
let clients = [];

test.before(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

test.after(async () => {
  clients.forEach(client => client.disconnect());
  await new Promise(resolve => io.close(resolve));
});

function connect() {
  const client = createClient(baseUrl, { transports: ['websocket'], forceNew: true });
  clients.push(client);
  return new Promise((resolve, reject) => {
    client.once('connect', () => resolve(client));
    client.once('connect_error', reject);
  });
}

function emitAck(client, event, payload) {
  return new Promise(resolve => payload === undefined ? client.emit(event, resolve) : client.emit(event, payload, resolve));
}

test('sanitizes player callsigns and detects world collisions', () => {
  assert.equal(cleanName('<b>Rot Brain!</b>'), 'bRot Brainb');
  assert.equal(cleanName(''), 'Survivor');
  assert.equal(circleHitsWall(5, 5, 20), true);
  assert.equal(circleHitsWall(900, 600, 20), false);
});

test('creates a room, joins a second player, and starts synchronized play', async () => {
  const host = await connect();
  const guest = await connect();
  const created = await emitAck(host, 'createRoom', { name: 'Nova', color: '#54d6a7' });
  assert.equal(created.ok, true);
  assert.match(created.code, /^[A-Z]{5}$/);

  const joined = await emitAck(guest, 'joinRoom', { code: created.code, name: 'Ash', color: '#ff6b6b' });
  assert.equal(joined.ok, true);
  assert.equal(rooms.get(created.code).players.size, 2);

  const roles = [];
  host.on('role', role => roles.push(role.role));
  guest.on('role', role => roles.push(role.role));
  const started = await emitAck(host, 'startGame');
  assert.equal(started.ok, true);
  await new Promise(resolve => setTimeout(resolve, 100));

  const room = rooms.get(created.code);
  assert.equal(room.phase, 'play');
  assert.equal(room.zombies.size >= 7, true);
  assert.deepEqual([...room.players.values()].map(p => p.role).sort(), ['infected', 'survivor']);
  assert.deepEqual(roles.sort(), ['infected', 'survivor']);
});
