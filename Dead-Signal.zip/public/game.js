const socket = io();

const $ = id => document.getElementById(id);
const screens = { menu: $('menu'), lobby: $('lobby'), game: $('game') };
const colors = ['#54d6a7', '#ff6b6b', '#5aa9ff', '#ffd166', '#b98cff', '#ff8dc7', '#f39c4a', '#9ee493'];
let selectedColor = colors[0];
let state = null;
let playerId = null;
let roomCode = '';
let currentRole = 'survivor';
let input = { up: false, down: false, left: false, right: false, angle: 0 };
let mouse = { x: innerWidth / 2, y: innerHeight / 2 };
let camera = { x: 0, y: 0 };
let voted = false;
let lastStateAt = Date.now();

const canvas = $('canvas');
const ctx = canvas.getContext('2d');

function show(name) {
  Object.entries(screens).forEach(([key, node]) => node.classList.toggle('hidden', key !== name));
}

function escapeHtml(text) {
  const div = document.createElement('div'); div.textContent = text; return div.innerHTML;
}

colors.forEach(color => {
  const btn = document.createElement('button');
  btn.className = 'swatch' + (color === selectedColor ? ' selected' : '');
  btn.style.background = color; btn.title = color;
  btn.onclick = () => {
    selectedColor = color;
    document.querySelectorAll('.swatch').forEach(x => x.classList.toggle('selected', x === btn));
  };
  $('colors').appendChild(btn);
});

function profile() {
  return { name: $('nameInput').value || localStorage.getItem('deadSignalName') || 'Survivor', color: selectedColor };
}

function enterRoom(result) {
  if (!result.ok) { $('menuError').textContent = result.error; return; }
  playerId = result.playerId; roomCode = result.code; localStorage.setItem('deadSignalName', profile().name);
  $('roomCode').textContent = roomCode; $('hudCode').textContent = roomCode;
  $('menuError').textContent = ''; show('lobby');
}

$('nameInput').value = localStorage.getItem('deadSignalName') || '';
$('createBtn').onclick = () => socket.emit('createRoom', profile(), enterRoom);
$('joinBtn').onclick = () => socket.emit('joinRoom', { ...profile(), code: $('codeInput').value }, enterRoom);
$('codeInput').addEventListener('input', e => e.target.value = e.target.value.toUpperCase().replace(/[^A-Z]/g, ''));
$('codeInput').addEventListener('keydown', e => { if (e.key === 'Enter') $('joinBtn').click(); });
$('copyCode').onclick = async () => {
  try { await navigator.clipboard.writeText(roomCode); $('copyCode').textContent = 'COPIED'; setTimeout(() => $('copyCode').textContent = 'COPY CODE', 1200); } catch {}
};
$('readyBtn').onclick = () => {
  const me = state?.players.find(p => p.id === playerId); socket.emit('setReady', !me?.ready);
};
$('startBtn').onclick = () => socket.emit('startGame', result => { if (!result.ok) $('lobbyHint').textContent = result.error; });
$('againBtn').onclick = () => socket.emit('playAgain');

socket.on('connect', () => { $('connection').innerHTML = '<span></span> LINKED'; });
socket.on('disconnect', () => { $('connection').textContent = 'SIGNAL LOST'; });

socket.on('role', role => {
  currentRole = role.role;
  $('roleTitle').textContent = role.title;
  $('roleDescription').textContent = role.description;
  $('roleCard').classList.remove('hidden');
  $('infectedAction').classList.toggle('hidden', currentRole !== 'infected');
  $('mobileAbility').classList.toggle('hidden', currentRole !== 'infected');
  setTimeout(() => $('roleCard').classList.add('hidden'), 4800);
});

socket.on('toast', text => {
  $('alert').textContent = text; $('alert').classList.remove('hidden');
  setTimeout(() => $('alert').classList.add('hidden'), 3200);
});

socket.on('chat', msg => {
  const row = document.createElement('div'); row.className = 'chat-message';
  row.innerHTML = `<b style="color:${msg.color}">${escapeHtml(msg.name)}</b>${escapeHtml(msg.text)}`;
  $('chatMessages').appendChild(row); $('chatMessages').scrollTop = 99999;
});

$('chatForm').onsubmit = event => {
  event.preventDefault(); const value = $('chatInput').value.trim();
  if (value) socket.emit('chat', value); $('chatInput').value = '';
};

socket.on('state', next => {
  const oldPhase = state?.phase; state = next; lastStateAt = Date.now(); roomCode = next.code;
  if (next.phase === 'lobby') {
    show('lobby'); $('endScreen').classList.add('hidden'); renderLobby();
  } else {
    show('game'); renderHud();
    if (next.phase === 'meeting') renderMeeting(); else { $('meeting').classList.add('hidden'); voted = false; }
    if (next.phase === 'ended') renderEnd(); else $('endScreen').classList.add('hidden');
  }
  if (oldPhase !== 'play' && next.phase === 'play') requestAnimationFrame(draw);
});

function renderLobby() {
  $('roomCode').textContent = state.code; $('hudCode').textContent = state.code;
  $('playerList').innerHTML = state.players.map(p => `
    <div class="player-row">
      <div class="player-avatar" style="background:${p.color}"></div>
      <div><b>${escapeHtml(p.name)}${p.id === state.hostId ? ' ★' : ''}</b><small>${p.id === playerId ? 'YOU' : p.id === state.hostId ? 'HOST' : 'CREW'}</small></div>
      <div class="ready-state ${p.ready ? 'ready' : ''}">${p.ready ? 'READY' : 'STANDBY'}</div>
    </div>`).join('');
  const me = state.players.find(p => p.id === playerId);
  $('readyBtn').textContent = me?.ready ? 'CANCEL READY' : 'MARK READY';
  $('startBtn').classList.toggle('hidden', state.hostId !== playerId);
  $('lobbyHint').textContent = state.players.length === 1 ? 'You can deploy solo to practice, or invite a friend for the hidden-carrier mode.' : `${state.players.filter(p=>p.ready).length}/${state.players.length} crew ready`;
}

function renderHud() {
  const me = state.players.find(p => p.id === playerId); if (!me) return;
  $('healthText').textContent = Math.ceil(me.health);
  $('healthBar').style.width = `${me.health}%`;
  $('healthBar').style.background = me.health < 35 ? 'var(--red)' : '';
  $('ammoText').textContent = me.transformed ? '—' : me.ammo;
  $('reserveText').textContent = me.transformed ? '—' : me.reserve;
  $('objectiveList').innerHTML = state.objectives.map(o => `<div class="objective ${o.done ? 'done' : ''}"><i></i><span>${escapeHtml(o.label)}</span></div>`).join('');
  $('evacObjective').classList.toggle('hidden', !state.evacOpen);
  $('infectedAction').textContent = me.transformed ? 'HIDE MUTATION' : 'UNLEASH';
  $('meetingBtn').classList.toggle('hidden', !me.alive || state.phase !== 'play' || Math.hypot(me.x - 1240, me.y - 1330) > 105);
  const nearObjective = state.objectives.some(o => !o.done && Math.hypot(me.x-o.x, me.y-o.y)<85);
  const nearBody = state.bodies.some(b => Math.hypot(me.x-b.x, me.y-b.y)<90);
  $('prompt').classList.toggle('hidden', !me.alive || (!nearObjective && !nearBody));
}

function renderMeeting() {
  $('meeting').classList.remove('hidden');
  $('meetingReason').textContent = state.meeting.reason;
  const living = state.players.filter(p => p.alive);
  $('voteList').innerHTML = living.map(p => `<button class="vote-player" data-id="${p.id}"><i class="vote-dot" style="background:${p.color}"></i><span>${escapeHtml(p.name)}${p.id === playerId ? ' (you)' : ''}</span></button>`).join('') + '<button class="vote-player" data-id="skip"><i class="vote-dot" style="background:#79867f"></i><span>Skip vote</span></button>';
  document.querySelectorAll('.vote-player').forEach(btn => btn.onclick = () => {
    if (voted) return; voted = true; socket.emit('vote', btn.dataset.id);
    document.querySelectorAll('.vote-player').forEach(x => x.disabled = true);
  });
  updateMeetingTimer();
}

function updateMeetingTimer() {
  if (!state?.meeting || state.phase !== 'meeting') return;
  $('meetingTimer').textContent = Math.max(0, Math.ceil((state.meeting.endsAt - Date.now()) / 1000));
  requestAnimationFrame(updateMeetingTimer);
}

function renderEnd() {
  $('endScreen').classList.remove('hidden');
  const card = $('endScreen').querySelector('.end-card'); card.className = `end-card panel ${state.winner}`;
  $('endTitle').textContent = state.winner === 'survivors' ? 'SURVIVORS ESCAPED' : 'INFECTION CONSUMED ALL';
  $('endMessage').textContent = state.message;
  $('againBtn').classList.toggle('hidden', state.hostId !== playerId);
}

const keys = { w:'up', arrowup:'up', s:'down', arrowdown:'down', a:'left', arrowleft:'left', d:'right', arrowright:'right' };
addEventListener('keydown', e => {
  if (document.activeElement?.tagName === 'INPUT') return;
  const key = e.key.toLowerCase(); if (keys[key]) input[keys[key]] = true;
  if (key === 'e') socket.emit('interact');
  if (key === 'r') socket.emit('reload');
  if (key === 'q' && currentRole === 'infected') socket.emit('transform');
  if (key === 'x' && currentRole === 'infected') socket.emit('sabotage');
  if (key === ' ' && currentRole === 'infected') { e.preventDefault(); socket.emit('bite'); }
});
addEventListener('keyup', e => { const key = e.key.toLowerCase(); if (keys[key]) input[keys[key]] = false; });
canvas.addEventListener('mousemove', e => { mouse = { x: e.clientX, y: e.clientY }; });
canvas.addEventListener('mousedown', e => { if (e.button === 0) fire(); });
canvas.addEventListener('contextmenu', e => e.preventDefault());

function fire() {
  const me = state?.players.find(p => p.id === playerId); if (!me) return;
  if (me.transformed && currentRole === 'infected') return socket.emit('bite');
  if (me.ammo <= 0) return socket.emit('reload');
  socket.emit('shoot', { angle: Math.atan2(mouse.y - innerHeight / 2, mouse.x - innerWidth / 2) });
}

$('infectedAction').onclick = () => socket.emit('transform');
$('meetingBtn').onclick = () => socket.emit('callMeeting');
$('mobileShoot').addEventListener('touchstart', e => { e.preventDefault(); fire(); });
$('mobileInteract').addEventListener('touchstart', e => { e.preventDefault(); socket.emit('interact'); });
$('mobileAbility').addEventListener('touchstart', e => { e.preventDefault(); socket.emit('transform'); });

const joystick = $('joystick'), stick = joystick.querySelector('i');
function moveStick(e) {
  const touch = e.touches?.[0]; if (!touch) return;
  const rect = joystick.getBoundingClientRect(), cx = rect.left + rect.width/2, cy = rect.top + rect.height/2;
  let dx = touch.clientX-cx, dy = touch.clientY-cy; const length = Math.hypot(dx,dy), max=34;
  if(length>max){dx=dx/length*max;dy=dy/length*max}
  stick.style.transform=`translate(${dx}px,${dy}px)`;
  input.left=dx < -10; input.right=dx > 10; input.up=dy < -10; input.down=dy > 10;
}
joystick.addEventListener('touchstart', e => {e.preventDefault();moveStick(e)}, {passive:false});
joystick.addEventListener('touchmove', e => {e.preventDefault();moveStick(e)}, {passive:false});
joystick.addEventListener('touchend', () => { stick.style.transform=''; input.left=input.right=input.up=input.down=false; });

setInterval(() => {
  if (state?.phase !== 'play') return;
  const angle = Math.atan2(mouse.y - innerHeight / 2, mouse.x - innerWidth / 2);
  input.angle = angle; socket.emit('input', input);
}, 50);

function resize() {
  const dpr = Math.min(devicePixelRatio || 1, 2); canvas.width = innerWidth*dpr; canvas.height = innerHeight*dpr;
  ctx.setTransform(dpr,0,0,dpr,0,0);
}
addEventListener('resize', resize); resize();

function worldToScreen(x,y){return{x:x-camera.x,y:y-camera.y}}

function drawGrid() {
  ctx.fillStyle='#09130f';ctx.fillRect(0,0,innerWidth,innerHeight);
  const grid=80, ox=(-camera.x%grid), oy=(-camera.y%grid);
  ctx.strokeStyle='rgba(133,181,153,.035)';ctx.lineWidth=1;ctx.beginPath();
  for(let x=ox;x<innerWidth;x+=grid){ctx.moveTo(x,0);ctx.lineTo(x,innerHeight)}
  for(let y=oy;y<innerHeight;y+=grid){ctx.moveTo(0,y);ctx.lineTo(innerWidth,y)}ctx.stroke();
  // world boundary and faded road markings
  const o=worldToScreen(0,0);ctx.strokeStyle='rgba(120,240,174,.18)';ctx.strokeRect(o.x,o.y,state.world.width,state.world.height);
  ctx.strokeStyle='rgba(220,210,150,.08)';ctx.setLineDash([25,30]);ctx.beginPath();
  let a=worldToScreen(0,650), b=worldToScreen(2400,650);ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);
  a=worldToScreen(700,0);b=worldToScreen(700,1600);ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.setLineDash([]);
}

function drawWalls() {
  state.walls.forEach(w=>{const p=worldToScreen(w.x,w.y);ctx.fillStyle='#17231d';ctx.fillRect(p.x,p.y,w.w,w.h);ctx.fillStyle='rgba(139,176,153,.11)';ctx.fillRect(p.x,p.y,w.w,3);ctx.strokeStyle='rgba(0,0,0,.3)';ctx.strokeRect(p.x+.5,p.y+.5,w.w-1,w.h-1)});
  const zones=[{x:330,y:180,w:500,h:390,t:'NORTH RELAY'},{x:1050,y:120,w:620,h:300,t:'RESEARCH LAB'},{x:155,y:790,w:430,h:420,t:'TRIAGE'},{x:820,y:720,w:690,h:250,t:'DEPOT'},{x:1760,y:680,w:450,h:500,t:'DOCKS'},{x:1070,y:1220,w:420,h:250,t:'SAFEHOUSE'}];
  ctx.font='700 10px ui-monospace';ctx.fillStyle='rgba(158,185,168,.16)';zones.forEach(z=>{const p=worldToScreen(z.x+20,z.y+35);ctx.fillText(z.t,p.x,p.y)});
}

function drawObjective(o) {
  const p=worldToScreen(o.x,o.y), pulse=1+Math.sin(Date.now()/250)*.12;
  ctx.save();ctx.translate(p.x,p.y);ctx.globalAlpha=o.done?.25:1;ctx.strokeStyle=o.type==='relay'?'#78f0ae':'#ffd166';ctx.lineWidth=2;
  ctx.beginPath();ctx.arc(0,0,25*pulse,0,Math.PI*2);ctx.stroke();ctx.rotate(Math.PI/4);ctx.strokeRect(-10,-10,20,20);ctx.rotate(-Math.PI/4);
  ctx.fillStyle=ctx.strokeStyle;ctx.font='700 9px ui-monospace';ctx.textAlign='center';ctx.fillText(o.done?'COMPLETE':o.type==='relay'?'RELAY':'SAMPLE',0,-37);ctx.restore();
}

function drawBody(b){const p=worldToScreen(b.x,b.y);ctx.save();ctx.translate(p.x,p.y);ctx.rotate(-.35);ctx.fillStyle=b.color;ctx.globalAlpha=.7;ctx.beginPath();ctx.ellipse(0,0,28,14,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#240a0a';ctx.beginPath();ctx.arc(12,3,8,0,Math.PI*2);ctx.fill();ctx.restore()}

function drawPlayer(p) {
  const q=worldToScreen(p.x,p.y);ctx.save();ctx.translate(q.x,q.y);ctx.rotate(p.angle);
  if(!p.alive)ctx.globalAlpha=.23;
  if(p.transformed){
    ctx.shadowColor='#c82b61';ctx.shadowBlur=18;ctx.fillStyle='#7e2445';ctx.beginPath();
    for(let i=0;i<12;i++){const a=i/12*Math.PI*2,r=i%2?18:28;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r)}ctx.closePath();ctx.fill();
    ctx.fillStyle='#f4d8df';ctx.beginPath();ctx.arc(11,-6,4,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
  }else{
    ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(-2,18,21,8,0,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=p.color;roundRect(-18,-20,36,42,13);ctx.fill();
    ctx.fillStyle=shade(p.color,-28);roundRect(-19,10,13,20,5);ctx.fill();roundRect(6,10,13,20,5);ctx.fill();
    ctx.fillStyle='#bfe5de';roundRect(5,-14,20,11,5);ctx.fill();ctx.fillStyle='rgba(255,255,255,.35)';roundRect(8,-12,12,3,2);ctx.fill();
    ctx.fillStyle='#101713';ctx.fillRect(18,-2,18,5);ctx.fillStyle='#788a80';ctx.fillRect(29,-4,9,9);
  }
  ctx.restore();ctx.save();ctx.translate(q.x,q.y);ctx.textAlign='center';ctx.font='700 10px system-ui';ctx.fillStyle=p.id===playerId?'#fff':'#a9b6ae';ctx.fillText(p.name,0,-34);
  if(p.health<100&&p.alive){ctx.fillStyle='#1d2822';ctx.fillRect(-20,-28,40,3);ctx.fillStyle=p.health<35?'#ff5d5d':'#78f0ae';ctx.fillRect(-20,-28,40*p.health/100,3)}ctx.restore();
}

function drawZombie(z){const p=worldToScreen(z.x,z.y);ctx.save();ctx.translate(p.x,p.y);ctx.rotate(z.angle);ctx.fillStyle=z.kind==='runner'?'#b6b04b':'#638758';ctx.beginPath();ctx.ellipse(0,0,17,21,0,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#87aa78';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-9,7);ctx.lineTo(-26,16);ctx.moveTo(10,5);ctx.lineTo(28,12);ctx.stroke();ctx.fillStyle='#ff5252';ctx.beginPath();ctx.arc(8,-7,3,0,Math.PI*2);ctx.fill();ctx.restore()}

function roundRect(x,y,w,h,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r)}
function shade(hex, amount){const n=parseInt(hex.slice(1),16),r=Math.max(0,Math.min(255,(n>>16)+amount)),g=Math.max(0,Math.min(255,((n>>8)&255)+amount)),b=Math.max(0,Math.min(255,(n&255)+amount));return`rgb(${r},${g},${b})`}

function draw() {
  if (!state || screens.game.classList.contains('hidden')) return;
  const me=state.players.find(p=>p.id===playerId);
  if(me){camera.x+=(me.x-innerWidth/2-camera.x)*.18;camera.y+=(me.y-innerHeight/2-camera.y)*.18}
  ctx.clearRect(0,0,innerWidth,innerHeight);drawGrid();drawWalls();
  state.objectives.forEach(drawObjective);
  if(state.evacOpen){const p=worldToScreen(2300,1380);ctx.fillStyle='rgba(255,209,102,.12)';ctx.strokeStyle='#ffd166';ctx.lineWidth=2;ctx.fillRect(p.x-70,p.y-90,120,180);ctx.strokeRect(p.x-70,p.y-90,120,180);ctx.fillStyle='#ffd166';ctx.font='800 10px ui-monospace';ctx.fillText('EVAC',p.x-27,p.y-100)}
  state.bodies.forEach(drawBody);state.zombies.forEach(drawZombie);
  state.players.filter(p=>p.id!==playerId).forEach(drawPlayer);if(me)drawPlayer(me);
  state.bullets.forEach(b=>{const p=worldToScreen(b.x,b.y);ctx.fillStyle='#ffe19a';ctx.shadowColor='#ffc64b';ctx.shadowBlur=8;ctx.beginPath();ctx.arc(p.x,p.y,3,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0});
  if(state.blackout){const g=ctx.createRadialGradient(innerWidth/2,innerHeight/2,80,innerWidth/2,innerHeight/2,260);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.94)');ctx.fillStyle=g;ctx.fillRect(0,0,innerWidth,innerHeight);$('alert').textContent='GRID SABOTAGED // VISIBILITY LOST';$('alert').classList.remove('hidden')} else if($('alert').textContent.startsWith('GRID'))$('alert').classList.add('hidden');
  renderHud();requestAnimationFrame(draw);
}
